% PAM Create an M-PAM symbol sequence 
%    PAM(N,M,sig2) creates an M-ary Pulse Amplitude Modulation (PAM) symbol 
%    sequence with length N and variance sig2.
function seq=pam(len,M,Var);
seq=2*floor(M*rand(1,len))-M+1;
seq=seq*sqrt(3*Var/(M^2-1));
