% PSK Create an M-PSK symbol sequence 
%    PSK(N,M,sig2) creates an M-ary Phase Shift Keyed (PSK) symbol 
%    sequence with length N and variance sig2.
function seq=psk(len,M,Var);
ang=2*pi/M*floor(M*rand(1,len));
seq=cos(ang)+j*sin(ang);
seq=seq*sqrt(Var);


