% QAM Create an M^2-QAM symbol sequence 
%    QAM(N,M,sig2) creates an M^2-ary Quadrature Amplitude Modulation (QAM) 
%    symbol sequence with length N and variance sig2.
function seq=qam(len,M,Var);
seq=2*floor(M*rand(1,len))-M+1+j*(2*floor(M*rand(1,len))-M+1);
seq=seq*sqrt(3/2*Var/(M^2-1));


